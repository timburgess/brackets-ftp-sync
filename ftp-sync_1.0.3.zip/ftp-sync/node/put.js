/*
 * Copyright (c) 2013-2014 Tim Burgess. All rights reserved.
 *  
 * @author Tim Burgess <info@tim-burgess.com>
 * @license Tim Burgess 2014
 */

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4,
maxerr: 50, node: true, white: true */
/* global */


"use strict";

var os = require("os"),
 JSFtp = require("jsftp"),
    fs = require("fs");

var _domainManager;

var HOST = "webedge";
var PORT = 21;
var USER = "a9113008";
var PWD = "koen11";
var LOCALROOT = "/Users/tim/work/test";
var REMOTEROOT = "public_html";

var ftp = new JSFtp({
    host: HOST
});
var processOps = false;
var haltCalled = false;
var ops = [];

var emit = false; // emit events to Brackets


    
function final(emitOK) {
    if (emitOK === undefined) { emitOK = true; }
    ftp.raw.quit(function (err, data) {
        //if (emitOK) {
        //    emit && _domainManager.emitEvent("ftpsync", "disconnected", data.text);
        //}
        console.log("final:" + data.text);
        // reset flags
        processOps = false;
        haltCalled = false;
    });
}

// control-flow
/*function series(op) {

    if (op) {
        if (haltCalled) {
            ops = [];
            return final();
        }
        var func = op[0];
        func(op[1], op[2]);
    } else {
        return final();
    }
}*/

// make a remote dir
/*function dirOp(localPath, remotePath) {
    console.log('mkdir ' + remotePath);
    ftp.raw.mkd(remotePath, function (err) {
        if (err) {
            if (err.code !== 550) {
                console.log('remote mkdir failed:' + err);
            }
        } else {
            emit && _domainManager.emitEvent("ftpsync", "mkdir", "created " + remotePath);
            console.log('created remote dir ' + remotePath); }
        return series(ops.shift());
    });
}*/

// push up a copy of local file
function putOp(localPath, remotePath) {
    console.log(localPath + '->' + remotePath);

    ftp.getPutSocket(remotePath, function (err, socket) {
        if (err) {
            console.log('socket fail:' + err);
        } else {
            var read = fs.createReadStream(localPath, { bufferSize: 4 * 1024 });
            // socket is a writeable stream
            read.pipe(socket);
            read.on("error", function(err) {
                console.log('socket error:' + err);
            });
            //read.on("end", function() {
                //emit && _domainManager.emitEvent("ftpsync", "uploaded", "uploaded " + remotePath);
                //console.log('uploaded ' + remotePath);
                //return series(ops.shift());
            //});
        }
    },
    function () { // doneCallback
        console.log('uploaded ' + remotePath);
        
        ftp.raw.quit(function (err, data) {
            console.log("quit:" + data.text);
        });

    });
}



        
    
// connect to remote
ftp.auth(USER, PWD, function (err, data) {
    
    if (err) { 
        //emit && _domainManager.emitEvent("ftpsync", "error", err.toString());
        console.log('Failed to connect to remote: ' + err);
        return;
    }
    console.log('Connected ' + data.text);

    // check REMOTEROOT is a valid directory
    ftp.raw.cwd("public_html");
    
    putOp('/Users/tim/work/test/index.html','/public_html/index.html');
    
});
                            
